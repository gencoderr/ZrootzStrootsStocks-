Certain unstable features can enable additional functionality useful to
cross-compiling. Note that these are unstable, and may be removed at any time
(particularly if the feature is stabilized or removed), and will only be used
on a nightly channel.

Here is the list of currently available unstable features:

- `CROSS_UNSTABLE_ENABLE_DOCTESTS`: enable or disable running doctests
  (example: `true`)
