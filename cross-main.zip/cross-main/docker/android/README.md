android
=======

Utilities for working with the Android project, particularly, for modifying and working with the Android build system. This facilitates modifying both Soong and Make build files, to remove unittests to speed up builds and minimize the number of dependencies.
