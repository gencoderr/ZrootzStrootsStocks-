#!/usr/bin/env bash

rm -rf /var/lib/apt/lists
rm -rf /usr/local/doc
