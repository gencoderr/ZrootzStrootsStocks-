#!/usr/bin/env bash
cargo xtask check --verbose
