#!/usr/bin/env bash
cargo xtask test --verbose
