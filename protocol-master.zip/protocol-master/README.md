# protocol [![Build Status](https://travis-ci.org/tronprotocol/protocol.svg?branch=master)](https://travis-ci.org/tronprotocol/protocol)


# The protocol of Tron including api and message.

The protocol is an independent project. You can use it for building other application. 

java-tron, wallet-cli and grpc-gateway

git subtree pull --prefix src/main/protos/ protocol master

## Run the included *.sh files to initialize the dependencies

